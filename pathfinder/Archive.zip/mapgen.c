//
//  mapgen.c
//  
//
//  Created by Lukas Labhart on 7/15/13.
//
//

#include "mapgen.h"
#include "lookup.h"



void MAPGEN_init()
{
    //Hard coded map
    memmove(myObstacles.x, (int[]){ 250, 330, 760, 700, 670}, sizeof(myObstacles.x));
    memmove(myObstacles.y, (int[]){ 250, 680, 870, 575, 200}, sizeof(myObstacles.y));
    memmove(myObstacles.r, (int[]){ 100, 75, 50, 130, 95}, sizeof(myObstacles.r));
    
    for (short i=0; i<N_OBS;i++)
    {
        myObstacles.r[i]+= SAFETY_MARGIN;
        myObstacles.x[i]-=500;
        myObstacles.y[i]-=500;
        myObstacles.visible[i] = 0;
    }  
    
    //printf("Point 43 to 67: %f\n", myMap.delta[67][43]);
    
    //for (int i=0; i<N_POINTS; i++)
    //    printf("%d: x=%f, y=%f\n", i, myMap.x[i], myMap.y[i]);
}

int MAPGEN_collision(int start, int end)
{
    float lambda;
    float gamma;
    
    //Some reused variables
    float dx = myMap.x[end]-myMap.x[start];
    float dy = myMap.y[end]-myMap.y[start];
    float det = (dx*dx+dy*dy);
    
    //Scan through all the obstacles
    for (short i=0; i<N_OBS; i++)
    {
        
        //Only check the ones visible for the vehicle
        if (myObstacles.visible[i] > 0)
        {
            //Geometric check whether the shortest distance is smaller than the radius of the observed obstacle
            // return 1 on collision, else 0
            lambda = dx*(myObstacles.x[i]-myMap.x[start])+dy*(myObstacles.y[i]-myMap.y[start]);
            //gamma = 1000000/(float)(det)*((float)(dx)/1000*(float)(myObstacles.y[i]-myMap.y[start])/1000-(float)(dy)/1000*(float)(myObstacles.x[i]-myMap.x[start])/1000);
            gamma = ((float)(dx)*((float)(myObstacles.y[i])-(float)(myMap.y[start]))-(float)(dy)*((float)(myObstacles.x[i])-(float)(myMap.x[start])))/(float)(det);
            //printf("obstacle: %d, %d, %e, det: %d\n", i, lambda, gamma*gamma*det, (myObstacles.r[i]*myObstacles.r[i]));
            if (lambda <=det && lambda >=0 && gamma*gamma*(float)(det)<=(float)(myObstacles.r[i]*myObstacles.r[i]))
            {
                
                //printf("collision, lambda=%d, gamma=%d\n", start, end);
                return 1;
            }
        }
        
    }
    //printf("no collision\n");
    return 0;
}

void MAPGEN_visibility(float cLocx, float cLocy, int calpha)
{
    //Calculate new state variables
    MAPGEN_clear();
    
    myMap.x[END_P] = ENDX;
    myMap.y[END_P] = ENDY;
    myMap.is_in_bin[END_P] = 0;
    myMap.parent[END_P] = -1;
    myMap.dI[END_P] = INF;
    myMap.h[END_P] = 0;
    
#ifdef INT
    myMap.x[START_P] = (int)cLocx;
    myMap.y[START_P] = (int)cLocy;
    myMap.h[START_P] = (int)(sqrt(square(myMap.x[END_P]-myMap.x[START_P])+square(myMap.y[END_P]-myMap.y[START_P])));
#else
    myMap.x[START_P] = cLocx;
    myMap.y[START_P] = cLocy;
    myMap.h[START_P] = sqrt(square(myMap.x[END_P]-myMap.x[START_P])+square(myMap.y[END_P]-myMap.y[START_P]));
#endif
    myMap.is_in_bin[START_P] = 1;
    myMap.parent[START_P] = START_P;
    myMap.dI[START_P] = 0;
    myMap.alpha[START_P][START_P] = calpha;
    myMap.delta[START_P][START_P] = 10000;
    
    visible_objects = 0;
    
    for (short i = 0; i<N_OBS;i++)
    {
        if (square(cLocx-myObstacles.x[i])+square(cLocy-myObstacles.y[i]) < VISIBILITY)
        {
            myObstacles.visible[i] = (myObstacles.r[i] >= RMIN) ? 1 : 2;
            visible_objects += myObstacles.visible[i];
        }
        else
            myObstacles.visible[i] = 0;
    }
    
    short c;
    short g = 0;
    for (short i = 0; i<N_OBS; i++)
    {
        for (short p = 0; p < myObstacles.visible[i]; p++)
        {
            //Calculate the outlying radius of the polyhedra surrounding obstacle i
            float r_tilde = (p < 1) ? (myObstacles.r[i])*cos_l[N_DISC]+10 : (RMIN)*cos_l[N_DISC]+5;
            
            //printf("%d, %d\n", myObstacles.x[i], myObstacles.y[i]);
            //Discretize obstacle i with a polyhedra
            for (short j=0;j<N_DISC;j++)
            {
                c = g*N_DISC+j+2;
                //printf("%d\n", c);
                myMap.x[c] = (cos_l[j] > 0 ? (myObstacles.x[i] + (int)(r_tilde*cos_l[j])+1) : (myObstacles.x[i] + (int)(r_tilde*cos_l[j])));
                myMap.y[c] = (sin_l[j] > 0 ? (myObstacles.y[i] + (int)(r_tilde*sin_l[j])+1) : (myObstacles.y[i] + (int)(r_tilde*sin_l[j])));
                                
                myMap.is_in_bin[c] = 0;
                myMap.parent[c] = -1;
                myMap.dI[c] = INF;
#ifdef INT
                myMap.h[c] = (int)(sqrt(square(myMap.x[END_P]-myMap.x[c])+square(myMap.y[END_P]-myMap.y[c])));
                //printf("x of point %d: %d\n", c, myMap.h[c]);
                if(c != 0)
                {
                    for (short k=0;k<c;k++)
                    {
                        //On collision, set the distance to infinity
                        myMap.delta[c][k] = (MAPGEN_collision(c,k) == 0 ? (int)(sqrt(square(myMap.x[c]-myMap.x[k])+square(myMap.y[c]-myMap.y[k]))) : INF);
                        //printf("x of point %d: %d\n", c, myMap.delta[c][k]);
                    }
                }
#else
                myMap.h[c] = sqrt(square(myMap.x[END_P]-myMap.x[c])+square(myMap.y[END_P]-myMap.y[c]));
                //printf("x of point %d: %f\n", c, myMap.h[c]);
                if(c != 0)
                {
                    for (short k=0;k<c;k++)
                    {
                        //On collision, set the distance to infinity
                        //myMap.delta[c][k] = (MAPGEN_collision(c,k) == 0 ? sqrt(square(myMap.x[c]-myMap.x[k])+square(myMap.y[c]-myMap.y[k])) : INF);
                        if (MAPGEN_collision(c,k) == 0)
                        {
                            myMap.delta[c][k] = sqrt(square(myMap.x[c]-myMap.x[k])+square(myMap.y[c]-myMap.y[k]));
                            myMap.alpha[c][k] = arctan(myMap.x[c]-myMap.x[k], myMap.y[c]-myMap.y[k]);
                            //printf("alpha between point %d and %d is: %d\n", c, k, myMap.alpha[c][k]);
                        }
                        else
                            myMap.delta[c][k] = INF;
                        //printf("x of point %d: %f\n", c, myMap.delta[c][k]);
                    }
                }
#endif
            }
            g++;
        }
    }
    
    //Check collision also for the start and end node
#ifdef INT
    myMap.delta[END_P][START_P] = (MAPGEN_collision(END_P,START_P) == 0 ? (int)(sqrt(square(myMap.x[END_P]-myMap.x[START_P])+square(myMap.y[END_P]-myMap.y[START_P]))) : INF);
#else
    myMap.delta[END_P][START_P] = (MAPGEN_collision(END_P,START_P) == 0 ? sqrt(square(myMap.x[END_P]-myMap.x[START_P])+square(myMap.y[END_P]-myMap.y[START_P])) : INF);
    myMap.alpha[END_P][START_P] = arctan(myMap.x[END_P]-myMap.x[START_P], myMap.y[END_P]-myMap.y[START_P]);
#endif
    
}

void MAPGEN_clear()
{
    //Clear the discrete map
    memset(myMap.x, 0, sizeof(myMap.x));
    memset(myMap.y, 0, sizeof(myMap.y));
    memset(myMap.is_in_bin, 0, sizeof(myMap.is_in_bin));
    memset(myMap.parent, 0, sizeof(myMap.parent));
    memset(myMap.h, 0, sizeof(myMap.h));
    memset(myMap.dI, 0, sizeof(myMap.dI));
    memset(myMap.delta, 0, sizeof(myMap.delta));
}
