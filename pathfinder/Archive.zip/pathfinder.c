//
//  pathfinder.c
//  
//
//  Created by Lukas Labhart on 7/15/13.
//
//

#include "pathfinder.h"

void PF_astar()
{
    const int n_points = visible_objects*N_DISC+2;     //Number of visible obstacles*number of discrete points per obstacle
    //printf("Number of points: %d\n", visible_objects);
    
    //Some storage variables for the A* algorithm
    int bin[n_points];
    bin[0] = START_P;
    int bin_elements = 1;
    int removed;
#ifdef INT
    int delta;
    int* delta_check;
#else
    float delta;
    float* delta_check;
    float *delta_prev;
#endif
    int alpha_k, alpha_k1, r_current;
    unsigned long long cycle_start = rdtsc();
    //clock_t t = clock();
    
    //Scan through all points until no possible option is available
    while (bin_elements!=0)
    {
        bin_elements --;
        //Remove an element from the bin which is to be observed
        removed = bin[bin_elements];
        //printf("removed: %d\n", removed);
        
        //Flag this element as no longer in the bin
        myMap.is_in_bin[removed] = 0;
        
        //Iterate through all points to find the shortest distance between the removed and the observed point
        for (short i=0;i<n_points;i++)
        {
            //No need to observe the removed point
            if (i != removed)
            {
                //Get precalculated distance
                delta_check = (i > removed ?    &myMap.delta[i][removed] : &myMap.delta[removed][i]);
                //printf("%d, %d, %f\n", removed, i, *delta_check);
                //printf("%f\n", myMap.dI[END_P]);
#ifdef INT
                if (*delta_check != INF)
#else
                if (*delta_check != (float)(INF))
#endif
                {
                    //Update distance
                    delta = myMap.dI[removed]+*delta_check;
                    
                    //printf("Angle between point %d and %d is: %d\n", i, removed, alpha_k1-alpha_k);
                    //Compare whether the computed distance is shorter or not
                    if ((delta+myMap.h[i])<(myMap.dI[i]+myMap.h[i]) && (delta+myMap.h[i])< myMap.dI[END_P])
                    {
                        alpha_k = (removed >= myMap.parent[removed]) ? myMap.alpha[removed][myMap.parent[removed]] : (myMap.alpha[removed][myMap.parent[removed]] < 180 ? myMap.alpha[removed][myMap.parent[removed]]+180 : myMap.alpha[removed][myMap.parent[removed]]-180);
                        //printf("%d\n", alpha_k);
                        alpha_k1 = (i >= removed) ? myMap.alpha[i][removed] : (myMap.alpha[removed][i] < 180 ? myMap.alpha[removed][i] + 180 : myMap.alpha[removed][i] - 180);
                        
                        //if ((alpha_k1-alpha_k) <= 45 && (alpha_k1-alpha_k) >= -45)
                        //{
                        //printf("%d: delta=%d\n ", i, myMap.dI[i]);
                        //printf("%d\n", i);
                            delta_prev = (removed > myMap.parent[removed] ? & myMap.delta[removed][myMap.parent[removed]] : & myMap.delta[myMap.parent[removed]][removed]);
                            float tang1 = (alpha_k1-alpha_k) >= 0 ? tang((int)((alpha_k1-alpha_k)/2.)) : tang((int)((alpha_k-alpha_k1)/2.));
                            r_current = (tang1 != 0) ? (int)(*delta_prev/(2.*tang1)) : RMIN;
                            //if(i == END_P)
                                
                           //if (r_current >= RMIN)
                            if (r_current >= RMIN)
                            {
                                
                                //Set new shortest distance to point i
                                myMap.dI[i] = delta;
                                //Make the removed the parent node of point i
                                myMap.parent[i] = removed;
                                
                                //Add point i to bin, if not yet there
                                if (myMap.is_in_bin[i] == 0)
                                {
                                    //printf("%d, %d, %f, %d\n", removed, i, tang1, r_current);
                                    //printf("new item in bin: %d\n", i);
                                    bin[bin_elements] = i;
                                    bin_elements++;
                                    myMap.is_in_bin[i] = 1;
                                }
                           }
                        //}
                    }
                }
                
            }
        }
    }
    
    unsigned long long cycle_end = rdtsc();
    //t = clock()-t;
    unsigned int cycles = (unsigned int)(cycle_end-cycle_start);
    //printf("Cycles for the complete algorithm: %d\n", cycles);
    printf("Amount of time on a 50MHz CPU in ms: %f\n", (float)(cycles)/50000.0);
    //printf("Amount of time on a 2.4GHz CPU in ms: %f\n", (float)t/CLOCKS_PER_SEC*1000);
    //printf("x_end = %d\n", myMap.x[END_P]);
    //printf("%d\n", PF_collision(57,60));
}

void PF_reconstruct()
{
    float path_length = 0;
    int node = END_P;
    int prev_node = 0;
    //printf("Visible Objects: %d\n", visible_objects);
    while (node != START_P)
    {
        //printf("x: %f, y: %f, node: %d\n", myMap.x[node], myMap.y[node], node);
        if (node > myMap.parent[node])
            path_length += myMap.delta[node][myMap.parent[node]];
        else
            path_length += myMap.delta[myMap.parent[node]][node];
        prev_node = node;
        node = myMap.parent[node];
    }
    
    //Update the position towards the next point
    
    POSGEN_update(myMap.x[prev_node], myMap.y[prev_node], myMap.alpha[prev_node][START_P]);
    //printf("x: %f, y: %f, node: %d\n", myMap.x[node], myMap.y[node], node);
    printf("Shortest Path Length: %f\n",path_length);
    //float path_matlab = myMap.delta[END_P][55]+myMap.delta[55][32]+myMap.delta[33][32]+myMap.delta[34][33]+myMap.delta[35][34]+myMap.delta[120][35];
    //printf("Shortest Path Matlab: %f\n", path_matlab);
    //printf("%f", (float)(INF+INF));
}



